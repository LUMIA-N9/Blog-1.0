import logging
logging.basicConfig(level=logging.INFO)


class Getscore(object):
    def __init__(self):
        self.score = 999

    def __str__(self):
        return '<%s, %s>' % (self.__class__.__name__, self.name)


class ModelMetaClass(type):
    def __new__(cls, name, base, attrs):
        logging.info("cls is:" + str(cls))
        logging.info("name is:" + str(name))
        logging.info("base is:" + str(base))
        logging.info("attrs is:" + str(attrs))
        for k, v in attrs.items():
            if isinstance(v, Getscore):
                #print(k.score)
                print(v.score)
        return type.__new__(cls, name, base, attrs)


class Model(dict, metaclass=ModelMetaClass):
    def __init__(self):
        self.name = 'name'

    def hello(self):
        print('hello')

    six = 666


class User(Model):
    def __init__(self):
        print('hello model')
        self.age = 18

    def hello2(self):
        print('hello model again')

    score = Getscore()


def main():
    User()


if __name__ == '__main__':
    main()
