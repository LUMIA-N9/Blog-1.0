# config_override.py

configs = {'db': {'host': '127.6.0.1'}}
